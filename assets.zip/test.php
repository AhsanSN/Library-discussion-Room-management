<?


?>
<script>
    window.open("mailto:"+"emailTo"+'?cc='+"emailCC"+'&subject='+"emailSub"+'&body='+"emailBody", '_self');
</script>

